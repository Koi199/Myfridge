# Grocery list

A Pen created on CodePen.io. Original URL: [https://codepen.io/Koii19/pen/dyKJMwg](https://codepen.io/Koii19/pen/dyKJMwg).

